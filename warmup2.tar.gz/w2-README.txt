Documentation for Warmup Assignment 2
=====================================

+-------+
| BUILD |
+-------+

Comments: "make" or "make warmup2" can be used to create the executable file.

+-----------------+
| SKIP (Optional) |
+-----------------+

All the test cases provided in the test suite have successfully passed.

+---------+
| GRADING |
+---------+

Basic running of the code : 100 out of 100 pts

Missing required section(s) in README file : No, all sections are addressed
Cannot compile : Program can be successfully compiled
Compiler warnings : No compiler warnings are produced in my code
"make clean" : Removes all *.o files. Works as expected
Segmentation faults : No, no such faults are seen
Separate compilation : Yes
Using busy-wait : No
Handling of commandline arguments:
    1) -n : Yes
    2) -lambda : Yes
    3) -mu : Yes
    4) -r : Yes
    5) -B : Yes
    6) -P : Yes
Trace output :
    1) regular packets: Yes,displayed
    2) dropped packets: Yes,displayed
    3) removed packets: Yes,displayed
    4) token arrival (dropped or not dropped): Yes,displayed
Statistics output :
    1) inter-arrival time : Yes,displayed
    2) service time : Yes,displayed
    3) number of customers in Q1 : Yes,displayed
    4) number of customers in Q2 : Yes,displayed
    5) number of customers at a server : Yes,displayed
    6) time in system : Yes,displayed
    7) standard deviation for time in system : Yes,displayed
    8) drop probability : Yes,displayed
Output bad format : No, output is displayed as mentioned in spec 
Output wrong precision for statistics (should be 6-8 significant digits) : No, statistics precision is as mentioned in spec 
Large service time test : Yes, Performed
Large inter-arrival time test : Yes, Performed
Tiny inter-arrival time test : Yes, Performed
Tiny service time test : Yes, Performed
Large total number of customers test : Yes, Performed
Large total number of customers with high arrival rate test : Yes, Performed
Dropped tokens test : Yes, Performed
Cannot handle <Cntrl+C> at all (ignored or no statistics) : No, the code can handle <Cntrl+C>
Can handle <Cntrl+C> but statistics way off : No, the code outputs statistics as mentioned in the spec even when pressed <Cntrl+C>
Not using condition variables and do some kind of busy-wait : No, code does not perform busy wait
Synchronization check : Yes, checked
Deadlocks : Not seen any

+------+
| BUGS |
+------+

Comments: No Bugs

+------------------+
| OTHER (Optional) |
+------------------+

Comments on design decisions: The design decisions are based on rules and regulations provided in the spec. 

Overall Design: * If provided command line variables or input file, various validations are carried out on the fly based on the spec. 
	* Five threads are created(one each for packet,token,server1,server2 and <Cntrl+C> signal). 
	* Coordination between these threads are taken care by mutex(a single mutex is used).
	* Servers perform conditional wait to continue processing of packets.
	* My402List is used for Q1 list and Q2 list implementation. 
	* <Cntrl+C> signal is handled as expected.
	* Outputs statistics when all packets are served or if <Cntrl+C> is pressed.
	* On the fly mechanism is used at all places and the code does not busy wait anywhere.

Comments on deviation from spec: No deviation is made.


